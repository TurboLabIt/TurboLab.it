import trendingImg1 from "../assets/img/entertainment-dark-1.jpg";
import trendingImg2 from "../assets/img/entertainment-dark-2.jpg";
import trendingImg3 from "../assets/img/entertainment-dark-3.jpg";
import trendingImg4 from "../assets/img/entertainment-dark-4.jpg";
import trendingImg5 from "../assets/img/entertainment-dark-5.jpg";
import trendingImg6 from "../assets/img/entertainment-dark-6.jpg";
import trendingImg7 from "../assets/img/entertainment-dark-7.jpg";
export const trendings = [
  {
    image: trendingImg1,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "There may be no consoles in the future ea exec says",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: trendingImg2,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "There may be no consoles in the future ea exec says",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: trendingImg3,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "There may be no consoles in the future ea exec says",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: trendingImg4,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "There may be no consoles in the future ea exec says",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: trendingImg5,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "There may be no consoles in the future ea exec says",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: trendingImg6,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "There may be no consoles in the future ea exec says",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: trendingImg7,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "There may be no consoles in the future ea exec says",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: trendingImg1,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "There may be no consoles in the future ea exec says",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: trendingImg2,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "There may be no consoles in the future ea exec says",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: trendingImg3,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "There may be no consoles in the future ea exec says",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
];

export const trendings_news = [
  {
    photo: trendingImg1,
    category: "TECHNOLOGY",
    date: "April 26, 2020",
    title: "Japan’s virus puzzled the world luck running out?",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    photo: trendingImg2,
    category: "TECHNOLOGY",
    date: "April 26, 2020",
    title: "Japan’s virus puzzled the world luck running out?",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    photo: trendingImg3,
    category: "TECHNOLOGY",
    date: "April 26, 2020",
    title: "Japan’s virus puzzled the world luck running out?",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    photo: trendingImg4,
    category: "TECHNOLOGY",
    date: "April 26, 2020",
    title: "Japan’s virus puzzled the world luck running out?",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    photo: trendingImg5,
    category: "TECHNOLOGY",
    date: "April 26, 2020",
    title: "Japan’s virus puzzled the world luck running out?",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    photo: trendingImg6,
    category: "TECHNOLOGY",
    date: "April 26, 2020",
    title: "Japan’s virus puzzled the world luck running out?",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    photo: trendingImg7,
    category: "TECHNOLOGY",
    date: "April 26, 2020",
    title: "Japan’s virus puzzled the world luck running out?",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    photo: trendingImg1,
    category: "TECHNOLOGY",
    date: "April 26, 2020",
    title: "Japan’s virus puzzled the world luck running out?",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    photo: trendingImg2,
    category: "TECHNOLOGY",
    date: "April 26, 2020",
    title: "Japan’s virus puzzled the world luck running out?",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    photo: trendingImg3,
    category: "TECHNOLOGY",
    date: "April 26, 2020",
    title: "Japan’s virus puzzled the world luck running out?",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    photo: trendingImg4,
    category: "TECHNOLOGY",
    date: "April 26, 2020",
    title: "Japan’s virus puzzled the world luck running out?",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    photo: trendingImg5,
    category: "TECHNOLOGY",
    date: "April 26, 2020",
    title: "Japan’s virus puzzled the world luck running out?",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    photo: trendingImg6,
    category: "TECHNOLOGY",
    date: "April 26, 2020",
    title: "Japan’s virus puzzled the world luck running out?",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    photo: trendingImg7,
    category: "TECHNOLOGY",
    date: "April 26, 2020",
    title: "Japan’s virus puzzled the world luck running out?",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    photo: trendingImg1,
    category: "TECHNOLOGY",
    date: "April 26, 2020",
    title: "Japan’s virus puzzled the world luck running out?",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    photo: trendingImg2,
    category: "TECHNOLOGY",
    date: "April 26, 2020",
    title: "Japan’s virus puzzled the world luck running out?",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
];
