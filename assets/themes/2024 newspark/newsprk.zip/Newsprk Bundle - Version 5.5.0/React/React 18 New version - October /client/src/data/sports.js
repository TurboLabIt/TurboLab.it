import sports41 from "../assets/img/latest-news-3.png";
import sportsbig1 from "../assets/img/sports-news.jpg";
import video21 from "../assets/img/video21.jpg";
export const sports = [
  {
    image: sports41,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: sportsbig1,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: sports41,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: sportsbig1,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: sports41,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: sportsbig1,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: sports41,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: sportsbig1,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: sports41,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
  {
    image: sportsbig1,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
    body: "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…",
  },
];

export const sports_news = [
  {
    photo: video21,
    category: "SPORTS",
    date: "April 26, 2020",
    time: "8:36mm",
    title:
      "ICC Men’s Cricket World Cup digital content delivers record-breaking numbers",
  },
  {
    photo: video21,
    category: "SPORTS",
    date: "April 26, 2020",
    time: "8:36mm",
    title:
      "ICC Men’s Cricket World Cup digital content delivers record-breaking numbers",
  },
  {
    photo: video21,
    category: "SPORTS",
    date: "April 26, 2020",
    time: "8:36mm",
    title:
      "ICC Men’s Cricket World Cup digital content delivers record-breaking numbers",
  },
  {
    photo: video21,
    category: "SPORTS",
    date: "April 26, 2020",
    time: "8:36mm",
    title:
      "ICC Men’s Cricket World Cup digital content delivers record-breaking numbers",
  },
  {
    photo: video21,
    category: "SPORTS",
    date: "April 26, 2020",
    time: "8:36mm",
    title:
      "ICC Men’s Cricket World Cup digital content delivers record-breaking numbers",
  },
];
