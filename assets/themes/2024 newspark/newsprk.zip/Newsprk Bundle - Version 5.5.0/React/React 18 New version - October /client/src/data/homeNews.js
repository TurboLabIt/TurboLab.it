import finance41 from "../assets/img/finance/finance-1.jpg";
import international41 from "../assets/img/international-post/1.jpg";
import international42 from "../assets/img/international-post/2.jpg";
import international43 from "../assets/img/international-post/3.jpg";
import international44 from "../assets/img/international-post/4.jpg";
import international45 from "../assets/img/international-post/5.jpg";
export const internationalPosts = [
  {
    photo: international41,
    title: "Investors explain COVID-19’s impact on consumer startups",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with",
  },
  {
    photo: international42,
    title: "Investors explain COVID-19’s impact on consumer startups",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with",
  },
  {
    photo: international43,
    title: "Investors explain COVID-19’s impact on consumer startups",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with",
  },
  {
    photo: international44,
    title: "Investors explain COVID-19’s impact on consumer startups",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with",
  },
  {
    photo: international45,
    title: "Investors explain COVID-19’s impact on consumer startups",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with",
  },
  {
    photo: international43,
    title: "Investors explain COVID-19’s impact on consumer startups",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with",
  },
];

export const financePosts = [
  {
    photo: finance41,
    title: "Copa America: Luis Suarez from devastated US",
    description:
      "The property, complete with seates screening from room amphitheater pond with sandy",
  },
  {
    photo: finance41,
    title: "Copa America: Luis Suarez from devastated US",
    description:
      "The property, complete with seates screening from room amphitheater pond with sandy",
  },
];
export const financePosts2 = [
  {
    photo: finance41,
    title: "Copa America: Luis Suarez from devastated US",
    description:
      "The property, complete with seates screening from room amphitheater pond with sandy",
  },
  {
    photo: finance41,
    title: "Copa America: Luis Suarez from devastated US",
    description:
      "The property, complete with seates screening from room amphitheater pond with sandy",
  },
  {
    photo: finance41,
    title: "Copa America: Luis Suarez from devastated US",
    description:
      "The property, complete with seates screening from room amphitheater pond with sandy",
  },
];
