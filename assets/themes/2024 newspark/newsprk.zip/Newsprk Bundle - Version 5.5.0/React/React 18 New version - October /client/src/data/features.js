import fNews1 from "../assets/img/feature/feature-1.png";
import fNews2 from "../assets/img/feature/feature-2.png";
import fNews3 from "../assets/img/feature/feature-3.png";
import fNews4 from "../assets/img/feature/feature-4.png";
import fNews5 from "../assets/img/feature/feature-5.png";
import fNews6 from "../assets/img/feature/feature-6.png";
import fNews7 from "../assets/img/feature/feature-7.png";
import fNews8 from "../assets/img/feature/feature-8.png";

import international41 from "../assets/img/international-post/1.jpg";
import international42 from "../assets/img/international-post/2.jpg";
import international43 from "../assets/img/international-post/3.jpg";
import international44 from "../assets/img/international-post/4.jpg";
import international45 from "../assets/img/international-post/5.jpg";

export const features = [
  {
    image: fNews1,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Best garden wing supplies for the horticu ltural",
  },
  {
    image: fNews2,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
  {
    image: fNews3,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Best garden wing supplies for the horticu ltural",
  },
  {
    image: fNews4,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
  {
    image: fNews5,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Best garden wing supplies for the horticu ltural",
  },
  {
    image: fNews6,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
  {
    image: fNews7,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Best garden wing supplies for the horticu ltural",
  },
  {
    image: fNews8,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
  {
    image: fNews1,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Best garden wing supplies for the horticu ltural",
  },
  {
    image: fNews2,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
];
export const features2 = [
  {
    image: fNews1,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Best garden wing supplies for the horticu ltural",
  },
  {
    image: fNews2,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
  {
    image: fNews3,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Best garden wing supplies for the horticu ltural",
  },
  {
    image: fNews4,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
  {
    image: fNews5,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Best garden wing supplies for the horticu ltural",
  },
  {
    image: fNews6,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
  {
    image: fNews7,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Best garden wing supplies for the horticu ltural",
  },
  {
    image: fNews8,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
  {
    image: fNews1,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Best garden wing supplies for the horticu ltural",
  },
  {
    image: fNews2,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
  {
    image: fNews3,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
  {
    image: fNews4,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
  {
    image: fNews1,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Best garden wing supplies for the horticu ltural",
  },
  {
    image: fNews2,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
  {
    image: fNews3,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Best garden wing supplies for the horticu ltural",
  },
  {
    image: fNews4,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
  {
    image: fNews5,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Best garden wing supplies for the horticu ltural",
  },
  {
    image: fNews6,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
  {
    image: fNews7,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Best garden wing supplies for the horticu ltural",
  },
  {
    image: fNews8,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
  {
    image: fNews1,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Best garden wing supplies for the horticu ltural",
  },
  {
    image: fNews2,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
  {
    image: fNews3,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
  {
    image: fNews4,
    category: "TECHNOLOGY",
    date: "March 26, 2020",
    title: "Copa America: Luis Suarez from devastated US",
  },
];

export const featurePosts = [
  {
    photo: international41,
    title: "Verizon is buying b2b video conferen firm Blue Jeans",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with",
  },
  {
    photo: international42,
    title: "Investors explain COVID-19’s impact on consumer startups",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with",
  },
  {
    photo: international43,
    title:
      "Unraveling immigration politics and Silicon Valley ethic with Jaclyn…",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with",
  },
  {
    photo: international42,
    title: "Bridgecrew announces $14M Series A to automate cloud security",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with",
  },
  {
    photo: international44,
    title: "She tried for many years pregnant & happy and thing going..",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with",
  },
  {
    photo: international42,
    title: "Bridgecrew announces $14M Series A to automate cloud security",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with",
  },
  {
    photo: international44,
    title: "She tried for many years pregnant & happy and thing going..",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with",
  },
  {
    photo: international45,
    title: "She tried for many years pregnant & happy and thing going..",
    description:
      "The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with",
  },
];
